love.graphics.setDefaultFilter("nearest", "nearest")

_CHUNKWIDTH = 16
_CHUNKHEIGHT = 10
_TILEWIDTH = 16
_TILEHEIGHT = 16

_GAMESCALE = 3
_16CAPACITY = (2^16)-1

love.window.setMode(_CHUNKWIDTH*_TILEWIDTH*_GAMESCALE, _CHUNKHEIGHT*_TILEHEIGHT*_GAMESCALE)

local world = require 'world'

function love.update(dt)
    world:process(dt)
end

function love.draw()
    world:draw()
end